from pathlib import Path
from pipelineproof.generator import generate_tasks


def test_generates_twelve_tasks(tmp_path: Path):
    tasks = generate_tasks(tmp_path / "tasks")
    assert len(tasks) == 12
    assert all((task / "pipeline.py").exists() for task in tasks)
