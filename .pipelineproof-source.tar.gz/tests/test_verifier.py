from pathlib import Path
from pipelineproof.controls import apply_control
from pipelineproof.generator import generate_tasks
from pipelineproof.verifier import verify_task


def test_gold_passes_all_tasks(tmp_path: Path):
    tasks = generate_tasks(tmp_path / "tasks")
    for task in tasks:
        apply_control(task, "gold")
        result = verify_task(task)
        assert result.passed, (task.name, result.to_dict())


def test_broken_tasks_do_not_all_pass(tmp_path: Path):
    tasks = generate_tasks(tmp_path / "tasks")
    results = [verify_task(task) for task in tasks]
    assert sum(result.passed for result in results) == 0
