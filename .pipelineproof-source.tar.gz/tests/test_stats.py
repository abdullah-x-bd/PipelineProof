from pipelineproof.stats import wilson_interval


def test_wilson_zero_has_nonzero_upper_bound():
    low, high = wilson_interval(0, 40)
    assert low == 0.0
    assert 0.08 < high < 0.10
