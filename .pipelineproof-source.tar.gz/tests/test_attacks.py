from pathlib import Path
import shutil
from pipelineproof.controls import ATTACKS, apply_control
from pipelineproof.generator import generate_tasks
from pipelineproof.verifier import verify_task


def test_attack_classes_are_rejected(tmp_path: Path):
    task = generate_tasks(tmp_path / "tasks")[0]
    for attack in ATTACKS:
        candidate = tmp_path / f"candidate-{attack}"
        shutil.copytree(task, candidate)
        apply_control(candidate, attack)
        assert not verify_task(candidate).passed, attack
