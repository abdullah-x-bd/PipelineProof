# PipelineProof

PipelineProof evaluates whether coding agents can repair ML pipelines that run successfully while violating training provenance, evaluation validity, or train-serving equivalence.

The package generates twelve original repository tasks across six defect families, verifies candidate repairs on fresh hidden data, and reports graded reward, false accepts, and false rejects.

## Install

```bash
python -m venv .venv
. .venv/bin/activate
python -m pip install -e ".[dev]"
```

## Run

```bash
pipelineproof generate --output tasks/generated
pipelineproof verify --task tasks/generated/feature_schema_a
pipelineproof soundness --output results/soundness.json
pipelineproof contamination --output results/contamination.json
pytest
python -m pip wheel . --no-deps -w dist
```

`verify` scores the repository currently present in the task directory. Generated tasks begin in their broken state. Use `pipelineproof apply-control` to install a labelled correct or adversarial implementation.

```bash
pipelineproof apply-control --task tasks/generated/feature_schema_a --control gold
pipelineproof verify --task tasks/generated/feature_schema_a
```

## Families

- feature schema mismatch
- preprocessing leakage
- missing preprocessing serialization
- evaluation on the wrong split
- group leakage across splits
- target-derived feature leakage

## Verification boundary

Candidate code runs as a subprocess in an isolated temporary workspace. Hidden datasets are created after the workspace is copied. The candidate never receives the trusted oracle implementation. Protected files are hashed before and after execution. A Docker image and sandbox command are included for scored use.

The local verifier is intended for development. The Docker path is the release isolation boundary. Build the candidate image with `docker build -f docker/Dockerfile.candidate -t pipelineproof-candidate:0.2.0 .` and pass `--sandbox docker` to `verify`.

## Evidence

`pipelineproof soundness` evaluates twelve correct controls and seventy-two adversarial controls. It writes per-class outcomes, Wilson 95% confidence intervals, and the reward ladder. No model leaderboard is claimed in the zero-cost release. Model rollouts and best-of-N experiments are the next stage.
