#!/usr/bin/env sh
set -eu
python -m pip install -e ".[dev]" --no-build-isolation
pytest
pipelineproof generate --output tasks/generated
pipelineproof soundness --output results/soundness.json
pipelineproof contamination --tasks tasks/generated --output results/contamination.json
python -m pip wheel . --no-deps --no-build-isolation -w dist
