# Failure taxonomy

- interface failure
- defect not located
- visible symptom repaired without restoring the contract
- predictive repair with evaluation regression
- public-test overfit
- protected-surface violation
- timeout or resource failure
- sandbox failure
- verifier failure
- task ambiguity
- harness failure
- genuine capability limitation
- human review required
