# Environment contract

Each task is a repository with one editable file, `pipeline.py`. The task manifest names the eligible features, target, family, seed, and protected surface.

The candidate must preserve two commands.

```text
python pipeline.py train --task TASK_JSON --train TRAIN_CSV --eval EVAL_CSV --artifact ARTIFACT_JSON --report REPORT_JSON
python pipeline.py predict --input INPUT_CSV --artifact ARTIFACT_JSON --output OUTPUT_CSV
```

The verifier creates fresh hidden data after copying the task into a temporary workspace. It checks output validity, predictive quality, column-order invariance, training provenance, batch-independent serving, evaluation integrity, and protected-file preservation.

Reward weights are fixed in `pipelineproof.verifier.WEIGHTS`. Passing requires reward of at least 0.85, valid execution, protected-file preservation, and predictive component of at least 0.8.
