# Sandbox manifest

Candidate image: `pipelineproof-candidate:0.2.0`

Scored configuration:

- network disabled
- read-only container filesystem
- 768 MB memory limit
- one CPU
- 128 process limit
- unprivileged UID 10001
- 20-second timeout per command in the verifier
- isolated temporary workspace per verification
- trusted hidden assets created outside the task directory

The trusted verifier runs outside the candidate image. Candidate code runs with Python isolated mode and site packages disabled. The candidate image contains no verifier package. The local subprocess runner is a development path and is not presented as a substitute for container isolation.
