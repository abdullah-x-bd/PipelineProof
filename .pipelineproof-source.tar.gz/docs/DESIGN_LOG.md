# Design log

## 2026-07-29

The initial proposal covered too many unrelated ML defects. The scope was reduced to six families governed by three integrity contracts.

The initial verifier concept relied on fixed hidden examples. It was replaced with fresh seeded datasets, causal interventions, and metamorphic checks.

The local runner and Docker isolation boundary were separated explicitly. The local path is for development and the container path is for scored use.
